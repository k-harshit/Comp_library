# Comp_library

this is a CSS library which can be used to insert ready-made/pre-written
code into their own projects to make them more attractive and presentable
